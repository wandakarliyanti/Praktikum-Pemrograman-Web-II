<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateDbModul6 extends Migration{
    public function up(){
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 7,
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'username' => [
                'type' => 'VARCHAR',
                'constraint' => '200',
            ],
            'email' => [
                'type' => 'VARCHAR',
                'constraint' => '200',
            ],
            'password' => [
                'type' => 'TEXT',
            ],
        ]);
        $this->forge->addKey('id', TRUE);
        $this->forge->createTable('user');

        $this->forge->addField([
            'id' => [
                'type' => 'BIGINT',
                'constraint' => 10,
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'judul' => [
                'type' => 'VARCHAR',
                'constraint' => '250',
            ],
            'penulis' => [
                'type' => 'VARCHAR',
                'constraint' => '250',
            ],
            'penerbit' => [
                'type' => 'VARCHAR',
                'constraint' => '250',
            ],
            'tahun_terbit' => [
                'type' => 'YEAR',
            ],
        ]);
        $this->forge->addKey('id', TRUE);
        $this->forge->createTable('buku');
    }

    public function down(){
        $this->forge->dropTable('user');
        $this->forge->dropTable('buku');
    }
}