<!DOCTYPE html>
<html>
    <head>
        <title>Data Buku</title>
        <style>
            body {
                margin: 0;
                padding: 0;
                display: flex;
                flex-direction: column;
                align-items: center;
                background: linear-gradient(to bottom left, #DAF0F6, #DEF0FF, #C7DEF8, #85B7F1, #73AFF6);
                background-size: cover;
                background-position: center;
                font-family: Arial, sans-serif;
                min-height: 100vh;
            }
            .navbar {
                width: 100%;
                display: flex;
                justify-content: flex-end;
                padding: 10px 20px 10px 0;
                background-color: white;
                border-radius: 5px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }
            .navbar a {
                color: #73AFF6;
                font-weight: bold;
                text-decoration: underline;
            }
            .container {
                width: 90%;
                max-width: 1200px;
                background-color: #FFFFFF;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                margin: 20px 0;
                padding: 20px;
            }
            .table-header {
                padding: 10px 20px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                background-color: #F7F7F7;
                border-bottom: 1px solid #E0E0E0;
            }
            .table-header h2 {
                margin: 0;
                font-size: 25px;
                color: black;
            }
            .table-header .add-button {
                padding: 5px 10px;
                background-color: #73AFF6;
                color: black;
                border: none;
                border-radius: 5px;
                font-size: 14px;
                text-decoration: none;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }
            table thead {
                background-color: #F7F7F7;
            }
            table th, table td {
                padding: 10px;
                text-align: left;
                border-right: 1px solid white;
                border-left: 1px solid white;
                border-bottom: 1px solid white;
                font-size: 14px;
            }
            table th {
                background-color: #E9ECEF;
                font-weight: bold;
            }
            table tbody tr:nth-child(even) {
                background-color: #F2F2F2;
            }
            .action-buttons {
                display: flex;
                gap: 10px;
            }
            .action-buttons a {
                text-decoration: none;
                color: #007BFF;
                font-weight: bold;
            }
            .action-buttons form {
                display: inline;
            }
            .action-buttons form button {
                background: none;
                border: none;
                color: #007BFF;
                font-weight: bold;
                cursor: pointer;
            }
        </style>
    </head>
    <body>
        <div class="navbar">
            <a href="/logout">Logout</a>
        </div>

        <div class="container">
            <div class="table-header">
                <h2>Data Buku</h2>
                <a href="<?= base_url('buku/create') ?>" class="add-button">Add New</a>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Judul</th>
                        <th>Penulis</th>
                        <th>Penerbit</th>
                        <th>Tahun Terbit</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (!empty($bukus)) : ?>
                        <?php foreach ($bukus as $book) : ?>
                            <tr>
                                <td><?= $book['id'] ?></td>
                                <td><?= $book['judul'] ?></td>
                                <td><?= $book['penulis'] ?></td>
                                <td><?= $book['penerbit'] ?></td>
                                <td><?= $book['tahun_terbit'] ?></td>
                                <td class="action-buttons">
                                    <a href="<?= base_url("buku/{$book['id']}/edit") ?>">Edit</a>
                                    <form method="post" action="<?= base_url("buku/{$book['id']}/delete") ?>">
                                        <?= csrf_field() ?>
                                        
                                        <button type="submit" name="delete">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="6">No records found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </body>
</html>